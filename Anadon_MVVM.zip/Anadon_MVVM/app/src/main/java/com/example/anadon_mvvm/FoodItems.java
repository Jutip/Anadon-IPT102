package com.example.anadon_mvvm;

public class FoodItems {
    private String name;
    private String price;

    public FoodItems(String name, String price) {
        this.name = name;
        this.price = price;
    }

    public String getName() { return name; }
    public String getPrice() { return price; }
}