package com.example.anadon_mvvm;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity{
    @Override
    protected void  onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        List<FoodItems> items = new ArrayList<FoodItems>();
        items.add(new FoodItems("Adobo", "P67"));
        items.add(new FoodItems("Lechon", "P150"));
        items.add(new FoodItems( "Halo-Halo", "P67"));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new FoodAdapter(this, items));
    }
}
