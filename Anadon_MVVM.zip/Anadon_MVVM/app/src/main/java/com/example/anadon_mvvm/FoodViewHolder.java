package com.example.anadon_mvvm;

public class FoodViewHolder {
}
